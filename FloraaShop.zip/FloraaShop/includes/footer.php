<footer class="footer">

   <section class="grid">

      <div class="box">
         <img src="images/email-icon.webp" alt="">
         <h3>our email</h3>
         <a href="mailto:cggpanes1@gmail.com">floraa@gmail.com</a>
         <a href="mailto:anasbhai@gmail.com">flowershop@gmail.com</a>
      </div>

      <div class="box">
         <img src="images/clock-icon.webp" alt="">
         <h3>opening hours</h3>
         <p>00:07am to 00:10pm</p>
      </div>

      <div class="box">
         <img src="images/map-icon.webp" alt="">
         <h3>our address</h3>
         <a href="#">Lemery Philipines- 5043</a>
      </div>

      <div class="box">
         <img src="images/phone-icon.webp" alt="">
         <h3>our number</h3>
         <a href="tel:1234567890">09971245162</a>
         <a href="tel:1112223333">111-222-3333</a>
      </div>

   </section>

   

</footer>

<div class="loader">
   <img src="images/flower-loader.gif" alt="">
</div>